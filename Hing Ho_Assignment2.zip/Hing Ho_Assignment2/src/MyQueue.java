import java.util.ArrayList;

/**
 * 
 * @author Hing Ho
 *
 * @param <T>
 */
public class MyQueue<T> implements QueueInterface<T> {
	private ArrayList<T> queue;
	private int size;

	/**
	 * Creates a constructor
	 */
	public MyQueue() {
		
	}
	
	
	/**
	 * Creates a constructor
	 * @param max
	 */
	public MyQueue(int max) {
		queue = new ArrayList<T>(max);
		size = max;
		
	}
	
	/**
	 * Determines if Queue is empty
	 * @return true if Queue is empty, false if not
	 */
	@Override
	public boolean isEmpty() {
		if(queue.size()==0) {
			return true;
		}
		else {
		return false;
		}
	}

	/**
	 * Determines if Queue is full
	 * @return true if Queue is full, false if not
	 */
	@Override
	public boolean isFull() {
		if(queue.size()==size) {
			return true;
		}
		else {
		return false;
		}
	}
 
	/**
	   * Deletes and returns the element at the front of the Queue
	   * @return the element at the front of the Queue
	   */
	@Override
	public T dequeue() throws QueueUnderflowException {
		if(isEmpty()) {
			throw new QueueUnderflowException();
		}
		return queue.remove(0);
	}

	 /**
	   * Number of elements in the Queue
	   * @return the number of elements in the Queue
	   */
	@Override
	public int size() {
		return queue.size();
	}

	 /**
	   * Adds an element to the end of the Queue
	   * @param e - the element to add to the Queue
	   * @return true if the add was successful, false if not
	   */
	@Override
	public boolean enqueue(T e) throws QueueOverflowException {
		if(queue.size() == size) {
			throw new QueueOverflowException();
		}
		queue.add(e);
		return true;
	}

	
	/**
	   * Returns the string of the elements in the Queue, 
	   * @return string of the Queue with elements
	   */
	@Override
	  public String toString() {
		String string = "";
		for(T element: queue) {
			string += element;
		}
		return string;
	  }
	
	 /**
	   * Returns the string of the elements in the Queue, 
	   * Place the delimiter between all elements of the Queue
	   * @param delimiter - string used to separate queue elements
	   * @return string of the Queue with elements separated with the delimiter
	   */
	@Override
	public String toString(String delimiter) {
		String string = "";
		for (T element : queue) {
			string += element + delimiter;
		}
		string = string.substring(0, string.length()-1);
		return string;
	}

	/**
	   * Fills the Queue with the elements of the ArrayList
	   * @param list - elements to be added to the Queue
	   */
	@Override
	public void fill(ArrayList<T> list) {
		for (T element : list) {
			try {
				this.enqueue(element);
			} catch (QueueOverflowException e) {
				e.printStackTrace();
			}
		}
	}

}
