import java.util.ArrayList;

/**
 * 
 * @author Hing Ho
 *
 */
public class Notation {
	private static MyQueue<String> queue;
	private static MyStack<String> stack;
	
	/**
	 * Creates a constructor
	 */
	private Notation() {
		
	}
	
	/**
	 * Convert an infix expression into a postfix expression
	 * @param infix
	 * @return postfix expression
	 * @throws InvalidNotationFormatException
	 */
	public static String convertInfixToPostfix(String infix) throws InvalidNotationFormatException {
		queue = new MyQueue<String>(infix.length());
		stack = new MyStack<String>(infix.length());
    
		String[] i = infix.split("");

		try {
			for (String c : i) {
				if (c.equals(" ")) {
					continue;
				}
				
				if (isInteger(c)) {
					queue.enqueue(c);
				}
				
				if (c.equals("(")) {
					stack.push(c);
				}
				
				if (isOperator(c)) {
					if (!stack.isEmpty() && isOperator(stack.top()) && Precedence(stack.top(),c)) {
						queue.enqueue(stack.pop());
					}
					stack.push(c);
				}

				if (c.equals(")")) {
					while (!stack.isEmpty() && isOperator(stack.top())) {
						queue.enqueue(stack.pop());
					}
					if(!stack.isEmpty() && stack.top().equals("(")) {
						stack.pop();
					} else {
						throw new Exception();
					}
				}
			}

			while (!stack.isEmpty() && isOperator(stack.top())) {
				queue.enqueue(stack.pop());
			}
		} catch (Exception e) {;
			throw new InvalidNotationFormatException();
		}
		return queue.toString();
	}
	
	
	/**
	 * Convert the postfix expression to the Infix expression
	 * @param postfix
	 * @return infix expression
	 * @throws InvalidNotationFormatException
	 */
	public static String convertPostfixToInfix(String postfix) throws InvalidNotationFormatException {
		queue = new MyQueue<String>(postfix.length());
		stack = new MyStack<String>(postfix.length());
		    
		MyStack<String> s_t = new MyStack<String>(2);

		String[] i = postfix.split("");

		try {
			for (String c : i) {
				if (c.equals(" ")) {
					continue;
				}

				if (isInteger(c)) {
					stack.push(c);
				} 

				if (isOperator(c)) {
					s_t.push(stack.pop());
					s_t.push(stack.pop());
					stack.push("("+s_t.pop()+c+s_t.pop()+")");
				}
			}

			if(stack.size()>1) {
				throw new Exception();
			}
		} catch (Exception e) {
			throw new InvalidNotationFormatException();
		}
		return stack.toString(); 
		 
	}
	
	/**
	 * Evaluates a postfix expression from a string to a double
	 * @param postfix
	 * @return postfix expression evaluated as double
	 * @throws InvalidNotationFormatException
	 */
	public static double evaluatePostfixExpression(String postfix) throws InvalidNotationFormatException {
		queue = new MyQueue<String>(postfix.length());
		stack = new MyStack<String>(postfix.length());
		    
		int r = 0;
		MyStack<String> s_t = new MyStack<String>(2);

		String[] i = postfix.split("");

		try {
			for (String c : i) {
				
				if (c.equals(" ")) {
					continue;
				}

				if (isInteger(c)) {
					stack.push(c);
				}

				if (isOperator(c)) {
					s_t.push(stack.pop());
					s_t.push(stack.pop());
					stack.push(String.valueOf(applyOperator(c,s_t.pop(),s_t.pop())));
				}
			}

			if(stack.size()>1) {
				throw new Exception();
			}
		} catch (Exception e) {
			throw new InvalidNotationFormatException();
		}
		return Integer.parseInt(stack.toString());
		  }

	
	
	private static boolean isInteger(String string) {
		try {
			Integer.parseInt(string);
		} catch (Exception e) {
			return false;
		}
		return true;
	}

	private static boolean isOperator(String string) {
		switch (string) {
		case "+":
		case "-":
		case "*":
		case "/":
			return true;
		default:
			return false;
		}
	}
	
	/**
	 * Checks precedence in operators
	 * @param a
	 * @param b
	 * @return if operator a >= b in precedence
	 */
	private static boolean Precedence(String a, String b) {
		int x;
		int y;
		
		 if (a=="*" || a=="/") {
		      x= 1;
		    } 
		 else {
		      x= 0;
		    }
		 
		 if (b=="*" || b=="/") {
		      y= 1;
		    } 
		 else {
		      y= 0;
		    }
		
		return x >= y;
	}
	
	
	private static int applyOperator(String operator, String first, String second) {
		int x = Integer.parseInt(first);
		int y = Integer.parseInt(second);
		switch(operator) {
		case "+":
			return x+y;
		case "-":
			return x-y;
		case "*":
			return x*y;
		case "/":
			return x/y;
		default:
		}
		return 0;
	}
	
	
}
