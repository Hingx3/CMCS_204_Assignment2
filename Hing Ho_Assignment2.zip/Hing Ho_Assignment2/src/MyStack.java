import java.util.ArrayList;


/**
 * 
 * @author Hing Ho
 *
 * @param <T>
 */
public class MyStack <T> implements StackInterface<T>{

	private ArrayList<T> stack;
	private int size;
	 
	/**
	 * Creates a constructor
	 */
	public MyStack() {
		
	}
	
	/**
	 * Creates a constructor
	 * @param max
	 */
	public MyStack(int max) {
		this.stack = new ArrayList<T>(max);
		this.size = max;
	}
	
	 /**
	   * Determines if Stack is empty
	   * @return true if Stack is empty, false if not
	   */
	@Override
	public boolean isEmpty() {
		if(stack.size()==0) {
			return true;
		}
		else {
		return false;
		}
	}

	/**
	   * Determines if Stack is full
	   * @return true if Stack is full, false if not
	   */
	@Override
	public boolean isFull() {
		if(stack.size()==size) {
			return true;
		}
		else {
		return false;
		}
	}

	/**
	   * Deletes and returns the element at the top of the Stack
	   * @return the element at the top of the Stack
	   */
	@Override
	public T pop() throws StackUnderflowException {
		if (isEmpty()) {
		      throw new StackUnderflowException();
		    }
						
		return stack.remove(stack.size() - 1);
	}

	/**
	   * Returns the element at the top of the Stack, does not pop it off the Stack
	   * @return the element at the top of the Stack
	   */
	@Override
	public T top() throws StackUnderflowException {
		 if (isEmpty()) {
		      throw new StackUnderflowException();
		    }
		    
		 return stack.get(stack.size() - 1);
	}

	/**
	   * Number of elements in the Stack
	   * @return the number of elements in the Stack
	   */
	@Override
	public int size() {
		return stack.size();
	}

	/**
	   * Adds an element to the top of the Stack
	   * @param e - the element to add to the top of the Stack
	   * @return true if the add was successful, false if not
	   */
	@Override
	public boolean push(T e) throws StackOverflowException {
		if (stack.size() == size) {
			throw new StackOverflowException();
		}
		stack.add(e);
		return true;
	}

	/**
	   * Returns the elements of the Stack in a string from bottom to top
	   * @return an string which represent the Objects in the Stack from bottom to top
	   */
	 @Override
	  public String toString() {
		 String string = "";
			for (T element : stack) {
				string += element;
			}
			return string;
	  }
	
	 /**
	   * Returns the string representation of the elements in the Stack
	   * Place the delimiter between all elements of the Stack
	   * @param delimiter - String to separate the elements of the stack
	   * @return string of the Stack from bottom to top with elements separated with the delimiter
	   */
	@Override
	public String toString(String delimiter) {
		String string = "";
		for (T element : stack) {
			string += element + delimiter;
		}
		string = string.substring(0, string.length() - 1);
		return string;
	}

	/**
	   * Fills the Stack with the elements of the ArrayList
	   * @param list - elements to be added to the Stack from bottom to top
	   */
	@Override
	public void fill(ArrayList<T> list) {
		for (T element : list) {
			try {
				this.push(element);
			} catch (StackOverflowException e) {
				e.printStackTrace();
			}
		}
		
	}

}
